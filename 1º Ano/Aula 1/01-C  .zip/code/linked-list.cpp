#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>

#include "linked-list.h"

namespace base {

   Node* destroy(Node* list)
   {
      return NULL;
   }

   Node* append(Node* list, uint32_t nmec, char *name)
   {
      return NULL;
   }

   void print(Node* list)
   {
   }

   int exists(Node* list, uint32_t nmec)
   {
      return 0;
   }

   Node* remove(Node* list, uint32_t nmec)
   {
      return NULL;
   }

   const char *search(Node* list, uint32_t nmec)
   {
      return NULL;
   }

   Node* sort_by_name(Node* list)
   {
      return NULL;
   }

   Node* sort_by_number(Node* list)
   {
      return NULL;
   }
}
